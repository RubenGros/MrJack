package com.company;


import java.util.Random;

public class Action_1 {

    private Boolean Recto_verso = true;

    public Action_1() {
    }


    public void retourner_jeton() {
        Recto_verso = !Recto_verso;
    }

    public int getcote(){
        int a= 0;
        if (Recto_verso){
            a=1;
        }
        return a;
    }

    public void rand_cote(){
        Random rand = new Random();
        this.Recto_verso = rand.nextBoolean();
    }
}