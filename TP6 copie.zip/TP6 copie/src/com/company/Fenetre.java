package com.company;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Fenetre extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;

    public Partie partie;
    public JLayeredPane contentPane = new JLayeredPane();
    public JButton[][] BoutonTab = new JButton[3][3]; // Plateau
    public JButton[] BoutonDetective = new JButton[3]; // Detective
    public JLabel TexteSablier; // texte pour les sabliers
    public JLabel TexteTour; // texte pour le tour
    public JButton CarteMechant; // la carte du mechant en bas a gauche
    public JButton[] CartesMechants = new JButton[4]; // Les cartes de MrJack en bas a gauche
    public JButton[] Jetons = new JButton[4]; // les boutons pour les jetons
    public JButton BoutonOK; // bouton ok quand on doit valider le tourner d une case
    public JButton Bouton1; // Avancer de 1
    public JButton Bouton2; // Avancer de 2
    public JButton BoutonC; // Avancer le chien
    public JButton BoutonW; // Avancer Watson
    public JButton BoutonH; // Avancer Holmes

    public int flag;
    public int flagi;
    public int flagj;

    public Fenetre(){
        super("MrJackPocket");
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setSize(800,600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.partie = new Partie();
        partie.jeton_action_1.rand_cote();
        partie.jeton_action_2.rand_cote();
        partie.jeton_action_3.rand_cote();
        partie.jeton_action_4.rand_cote();
        contentPane.setBounds(0, 0, 800, 600);

        for (int i = 0 ; i < 3 ; i++) {
            for (int j = 0 ; j < 3 ; j++) {
                BoutonTab[i][j] = new JButton();
                BoutonTab[i][j].setBounds(250 + j * 101, 125 + i * 101, 100, 100);
                BoutonTab[i][j].setIcon(new ImageIcon(Fenetre.class.getResource( "/CasePerso/"+partie.plateau.plateau[i][j].nom + partie.plateau.plateau[i][j].orientation() + ".png")));
                BoutonTab[i][j].addActionListener((ActionListener) this);
                contentPane.add(BoutonTab[i][j]);
            }
        }

        for (int i = 0 ; i < 3 ; i++) {
            BoutonDetective[i] = new JButton();
            BoutonDetective[i].setIcon(new ImageIcon(Fenetre.class.getResource("/Detectives/" + partie.liste_detective.getNom()[(i+2)%3] + ".png")));
            BoutonDetective[i].addActionListener((ActionListener) this);
            int t = 100;
            int j = 25;
            if (partie.liste_detective.getPosition()[i] == 0) {
                BoutonDetective[i].setBounds(175+t, 50+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 1) {
                BoutonDetective[i].setBounds(275+t, 50+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 2) {
                BoutonDetective[i].setBounds(375+t, 50+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 3) {
                BoutonDetective[i].setBounds(450+t, 125+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 4) {
                BoutonDetective[i].setBounds(450+t, 225+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 5) {
                BoutonDetective[i].setBounds(450+t, 325+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 6) {
                BoutonDetective[i].setBounds(375+t, 400+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 7) {
                BoutonDetective[i].setBounds(275+t, 400+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 8) {
                BoutonDetective[i].setBounds(175+t, 400+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 9) {
                BoutonDetective[i].setBounds(100+t, 325+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 10) {
                BoutonDetective[i].setBounds(100+t, 225+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 11) {
                BoutonDetective[i].setBounds(100+t, 125+j, 50, 50);
            }
            contentPane.add(BoutonDetective[i]);
        }

        TexteSablier = new JLabel(partie.joueur_mrjack.score_sablier_visible + " sabliers");
        TexteSablier.setBounds(700, 0, 100, 40);
        TexteSablier.setOpaque(true);
        TexteSablier.setBackground(Color.white);
        contentPane.add(TexteSablier);

        TexteTour = new JLabel("Tour du detective - Tour " + partie.numero_tour);
        TexteTour.setBounds(0, 0, 200, 30);
        TexteTour.setOpaque(true);
        TexteTour.setBackground(Color.white);
        contentPane.add(TexteTour);

        BoutonOK = new JButton("Ok !");
        BoutonOK.setBounds(700, 500, 50, 50);
        BoutonOK.addActionListener((ActionListener) this);
        contentPane.add(BoutonOK);
        BoutonOK.setVisible(false);

        Bouton1 = new JButton("1");
        Bouton1.setBounds(700, 500, 50, 50);
        Bouton1.addActionListener((ActionListener) this);
        contentPane.add(Bouton1);
        Bouton1.setVisible(false);

        Bouton2 = new JButton("2");
        Bouton2.setBounds(750, 500, 50, 50);
        Bouton2.addActionListener((ActionListener) this);
        contentPane.add(Bouton2);
        Bouton2.setVisible(false);

        BoutonC = new JButton("Chien");
        BoutonC.setBounds(730, 500, 75, 50);
        BoutonC.addActionListener((ActionListener) this);
        contentPane.add(BoutonC);
        BoutonC.setVisible(false);

        BoutonW = new JButton("Watson");
        BoutonW.setBounds(655, 500, 75, 50);
        BoutonW.addActionListener((ActionListener) this);
        contentPane.add(BoutonW); //Jeton 4 coté tourner surface
        BoutonW.setVisible(false);

        BoutonH = new JButton("Holmes");
        BoutonH.setBounds(580, 500, 70, 50);
        BoutonH.addActionListener((ActionListener) this);
        contentPane.add(BoutonH);
        BoutonH.setVisible(false);

        CarteMechant = new JButton();
        CarteMechant.setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/CarteRien.png")));
        CarteMechant.setBounds(0, 490, 60, 90);
        CarteMechant.addActionListener((ActionListener) this);
        contentPane.add(CarteMechant);

        for (int i = 0 ; i < 4 ; i++) {
            CartesMechants[i] = new JButton();
            CartesMechants[i].setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/CarteRien.png")));
            CartesMechants[i].setBounds(70 * (i + 1), 490, 60, 90);
            CartesMechants[i].addActionListener((ActionListener) this);
        }
        Jetons[0] = new JButton();
        Jetons[0].setIcon(new ImageIcon(Fenetre.class.getResource("/Actions/Jeton" + 3 + "" + partie.jeton_action_3.getcote() + ".png")));
        Jetons[0].setBounds(50 , 75, 50, 50);
        Jetons[0].addActionListener((ActionListener) this);
        contentPane.add(Jetons[0]);

        Jetons[1] = new JButton();
        Jetons[1].setIcon(new ImageIcon(Fenetre.class.getResource("/Actions/Jeton" + 2 + "" + partie.jeton_action_2.getcote() + ".png")));
        Jetons[1].setBounds(50, 150, 50, 50);
        Jetons[1].addActionListener((ActionListener) this);
        contentPane.add(Jetons[1]);

        Jetons[2] = new JButton();
        Jetons[2].setIcon(new ImageIcon(Fenetre.class.getResource("/Actions/Jeton" + 1 + "" + partie.jeton_action_1.getcote() + ".png")));
        Jetons[2].setBounds(50, 225, 50, 50);
        Jetons[2].addActionListener((ActionListener) this);
        contentPane.add(Jetons[2]);

        Jetons[3] = new JButton();
        Jetons[3].setIcon(new ImageIcon(Fenetre.class.getResource("/Actions/Jeton" + 4 + "" + partie.jeton_action_4.getcote() + ".png")));
        Jetons[3].setBounds(50, 300, 50, 50);
        Jetons[3].addActionListener((ActionListener) this);
        contentPane.add(Jetons[3]);
        this.add(contentPane);

    }

    public void refreshPlateau() {
        for (int i = 0 ; i < 3 ; i++) {
            for (int j = 0 ; j < 3 ; j++) {
                if (partie.plateau.plateau[i][j].suspect_vide)
                    BoutonTab[i][j].setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/"+partie.plateau.plateau[i][j].nom + partie.plateau.plateau[i][j].orientation() + ".png")));
                else
                    BoutonTab[i][j].setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/Vide" + partie.plateau.plateau[i][j].orientation() + ".png")));
            }
        }
    }

    public void refreshDetective() {
        int t = 100;
        int j = 25;
        for (int i = 0 ; i < 3 ; i++) {
            if (partie.liste_detective.getPosition()[i] == 0) {
                BoutonDetective[i].setBounds(175+t, 50+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 1) {
                BoutonDetective[i].setBounds(275+t, 50+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 2) {
                BoutonDetective[i].setBounds(375+t, 50+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 3) {
                BoutonDetective[i].setBounds(450+t, 125+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 4) {
                BoutonDetective[i].setBounds(450+t, 225+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 5) {
                BoutonDetective[i].setBounds(450+t, 325+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 6) {
                BoutonDetective[i].setBounds(375+t, 400+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 7) {
                BoutonDetective[i].setBounds(275+t, 400+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 8) {
                BoutonDetective[i].setBounds(175+t, 400+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 9) {
                BoutonDetective[i].setBounds(100+t, 325+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 10) {
                BoutonDetective[i].setBounds(100+t, 225+j, 50, 50);
            } else if (partie.liste_detective.getPosition()[i] == 11) {
                BoutonDetective[i].setBounds(100+t, 125+j, 50, 50);
            }
        }
    }

    public void refreshJeton() {
        Jetons[0].setIcon(new ImageIcon(Fenetre.class.getResource("/Actions/Jeton" + 3 + "" + partie.jeton_action_1.getcote() + ".png")));
        Jetons[1].setIcon(new ImageIcon(Fenetre.class.getResource("/Actions/Jeton" + 2 + "" + partie.jeton_action_2.getcote() + ".png")));
        Jetons[2].setIcon(new ImageIcon(Fenetre.class.getResource("/Actions/Jeton" + 1 + "" + partie.jeton_action_3.getcote() + ".png")));
        Jetons[3].setIcon(new ImageIcon(Fenetre.class.getResource("/Actions/Jeton" + 4 + "" + partie.jeton_action_4.getcote() + ".png")));
    }

    public void choixNbrDeplacement() {
        Bouton1.setVisible(true);
        Bouton2.setVisible(true);
    }

    public void pioche_carte() {
        Alibi alibi;

        if ((partie.numero_tour % 2 == 1 && (partie.numero_Etape == 0 || partie.numero_Etape == 3)) // Tour du detective
                || (partie.numero_tour % 2 == 0 && (partie.numero_Etape == 1 || partie.numero_Etape == 2))) {
            alibi= partie.deck.popPersonne();
            for (int i = 0 ; i < 3 ; i++) {
                for (int j = 0 ; j < 3 ; j++) {
                    if (partie.plateau.plateau[i][j].ID == alibi.ID) {
                        BoutonTab[i][j].setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/Vide" + partie.plateau.plateau[i][j].orientation() + ".png")));
                        partie.plateau.plateau[i][j].tourner();
                    }
                }
            }
        }
        else { // Tour de MrJack
            for (int i = 0 ; i < 4 ; i++) {
                if (partie.joueur_mrjack.carte[i].nombre_sablier == -1) {
                    partie.joueur_mrjack.carte[i] = partie.deck.popPersonne();
                    contentPane.add(CartesMechants[i]);
                    partie.joueur_mrjack.score_sablier += partie.joueur_mrjack.carte[i].nombre_sablier;
                    TexteSablier.setText(partie.joueur_mrjack.score_sablier_visible + " sabliers");
                    break;
                }
            }
        }
    }

    public void EtapeSupp() { // A la fin de l'action d'un jeu
        partie.numero_Etape++;
        if (partie.numero_Etape == 4) { // Si c'est la fin du tour
            TourSupp();
        }

        if ((partie.numero_tour % 2 == 1 && (partie.numero_Etape == 0 || partie.numero_Etape == 3))
                || (partie.numero_tour % 2 == 0 && (partie.numero_Etape == 1 || partie.numero_Etape == 2)))
        { TexteTour.setText("Tour du detective - Tour " + partie.numero_tour);}
        else { TexteTour.setText("Tour de MrJack - Tour " + partie.numero_tour); }
    }

    public void TourSupp() { // Si c'est la fin du tour
        partie.numero_Etape = 0;
        partie.numero_tour++;
        finTour(); // Fin d'un tour, on regarde quel quartier retourner et tout et tout
        if (finDuProgramme()) { // Si un des gars a gagne
            this.dispose();
        } // Fin ? Tour 8, ...
        if (partie.numero_tour % 2 == 1) {
            partie.jeton_action_1.rand_cote();
            partie.jeton_action_2.rand_cote();
            partie.jeton_action_3.rand_cote();
            partie.jeton_action_4.rand_cote();
        } else {
            partie.jeton_action_1.retourner_jeton();
            partie.jeton_action_2.retourner_jeton();
            partie.jeton_action_3.retourner_jeton();
            partie.jeton_action_4.retourner_jeton();
        }
        Jetons[0].setVisible(true);
        Jetons[1].setVisible(true);
        Jetons[2].setVisible(true);
        Jetons[3].setVisible(true);
        refreshJeton();
    }

    public boolean finDuProgramme() {
        if (partie.numero_tour > 8) {
            System.out.println("MrJack gagne");
            return (true);
        } else if (partie.joueur_mrjack.score_sablier >= 6) {
            System.out.println("MrJack gagne");
            return (true);
        } else if (SuspectRestant()) {
            System.out.println("Le detective gagne");
            return (true);
        }
        return (false);
    }

    public boolean SuspectRestant() {
        int count = 0;

        for (int i = 0 ; i < 3 ; i++) {
            for (int j = 0 ; j < 3 ; j++) {
                if (partie.plateau.plateau[i][j].suspect_vide) {
                    count++;
                }
            }
        }
        if (count == 1)
            return (true);
        return (false);
    }

    public void finTour() {
        ArrayList<Integer> vu = new ArrayList<Integer>();
        boolean dedans = false;

        for (int i=0;i<12;i++){
            if (partie.liste_detective.verifPosition(i)) { SuspectVu(i, vu, dedans); }
        }

        for (int j : vu) {
            if (partie.plateau.plateau[j / 3][j % 3].nom.equals(partie.joueur_mrjack.mrJack.nom_carte)) {
                dedans = true;
                break;
            }
        }
        if (!dedans) {
            for (int j : vu) {
                partie.plateau.plateau[j / 3][j % 3].tourner();
            }
            partie.joueur_mrjack.score_sablier++;
            partie.joueur_mrjack.score_sablier_visible++;
            TexteSablier.setText(partie.joueur_mrjack.score_sablier_visible + " sabliers");
        } else {
            for (int j = 0 ; j < 9 ; j++) {
                if (!vu.contains(j))
                    partie.plateau.plateau[j / 3][j % 3].tourner();
            }
        }
        refreshPlateau();
    }

    public void SuspectVu(int i, ArrayList<Integer> vu, boolean dedans) {
        if (i == 0) {
            if (partie.plateau.plateau[0][0].orientation() != 0) {
                if (vu.contains(0) == false)
                    vu.add(0);
                if (partie.plateau.plateau[0][0].orientation() != 2 && partie.plateau.plateau[1][0].orientation() != 0) {
                    if (vu.contains(3) == false)
                        vu.add(3);
                    if (partie.plateau.plateau[1][0].orientation() != 2 && partie.plateau.plateau[2][0].orientation() != 0) {
                        if (vu.contains(6) == false)
                            vu.add(6);
                    }
                }
            }
        } else if (i == 1) {
            if (partie.plateau.plateau[0][1].orientation() != 0) {
                if (vu.contains(1) == false)
                    vu.add(1);
                if (partie.plateau.plateau[0][1].orientation() != 2 && partie.plateau.plateau[1][1].orientation() != 0) {
                    if (vu.contains(4) == false)
                        vu.add(4);
                    if (partie.plateau.plateau[1][1].orientation() != 2 && partie.plateau.plateau[2][1].orientation() != 0) {
                        if (vu.contains(7) == false)
                            vu.add(7);
                    }
                }
            }
        } else if (i == 2) {
            if (partie.plateau.plateau[0][2].orientation() != 0) {
                if (vu.contains(2) == false)
                    vu.add(2);
                if (partie.plateau.plateau[0][2].orientation() != 2 && partie.plateau.plateau[1][2].orientation() != 0) {
                    if (vu.contains(5) == false)
                        vu.add(5);
                    if (partie.plateau.plateau[1][2].orientation() != 2 && partie.plateau.plateau[2][2].orientation() != 0) {
                        if (vu.contains(8) == false)
                            vu.add(8);
                    }
                }
            }
        } else if (i == 3) {
            if (partie.plateau.plateau[0][2].orientation() != 1) {
                if (vu.contains(2) == false)
                    vu.add(2);
                if (partie.plateau.plateau[0][2].orientation() != 3 && partie.plateau.plateau[0][1].orientation() != 1) {
                    if (vu.contains(1) == false)
                        vu.add(1);
                    if (partie.plateau.plateau[0][1].orientation() != 3 && partie.plateau.plateau[0][0].orientation() != 1) {
                        if (vu.contains(0) == false)
                            vu.add(0);
                    }
                }
            }
        } else if (i == 4) {
            if (partie.plateau.plateau[1][2].orientation() != 1) {
                if (vu.contains(5) == false)
                    vu.add(5);
                if (partie.plateau.plateau[1][2].orientation() != 3 && partie.plateau.plateau[1][1].orientation() != 1) {
                    if (vu.contains(4) == false)
                        vu.add(4);
                    if (partie.plateau.plateau[1][1].orientation() != 3 && partie.plateau.plateau[1][0].orientation() != 1) {
                        if (vu.contains(3) == false)
                            vu.add(3);
                    }
                }
            }
        } else if (i == 5) {
            if (partie.plateau.plateau[2][2].orientation() != 1) {
                if (vu.contains(8) == false)
                    vu.add(8);
                if (partie.plateau.plateau[2][2].orientation() != 3 && partie.plateau.plateau[2][1].orientation() != 1) {
                    if (vu.contains(7) == false)
                        vu.add(7);
                    if (partie.plateau.plateau[2][1].orientation() != 3 && partie.plateau.plateau[2][0].orientation() != 1) {
                        if (vu.contains(6) == false)
                            vu.add(6);
                    }
                }
            }
        } else if (i == 6) {
            if (partie.plateau.plateau[2][2].orientation() != 2) {
                if (!vu.contains(8))
                    vu.add(8);
                if (partie.plateau.plateau[2][2].orientation() != 0 && partie.plateau.plateau[1][2].orientation() != 2) {
                    if (!vu.contains(5))
                        vu.add(5);
                    if (partie.plateau.plateau[1][2].orientation() != 0 && partie.plateau.plateau[0][2].orientation() != 2) {
                        if (vu.contains(2) == false)
                            vu.add(2);
                    }
                }
            }
        } else if (i == 7) {
            if (partie.plateau.plateau[2][1].orientation() != 2) {
                if (vu.contains(7) == false)
                    vu.add(7);
                if (partie.plateau.plateau[2][1].orientation() != 0 && partie.plateau.plateau[1][1].orientation() != 2) {
                    if (vu.contains(4) == false)
                        vu.add(4);
                    if (partie.plateau.plateau[1][1].orientation() != 0 && partie.plateau.plateau[0][1].orientation() != 2) {
                        if (vu.contains(1) == false)
                            vu.add(1);
                    }
                }
            }
        } else if (i == 8) {
            if (partie.plateau.plateau[2][0].orientation() != 2) {
                if (vu.contains(6) == false)
                    vu.add(6);
                if (partie.plateau.plateau[2][0].orientation() != 0 && partie.plateau.plateau[1][0].orientation() != 2) {
                    if (vu.contains(3) == false)
                        vu.add(3);
                    if (partie.plateau.plateau[1][0].orientation() != 0 && partie.plateau.plateau[0][0].orientation() != 2) {
                        if (vu.contains(0) == false)
                            vu.add(0);
                    }
                }
            }
        } else if (i == 9) {
            if (partie.plateau.plateau[2][0].orientation() != 3) {
                if (vu.contains(6) == false)
                    vu.add(6);
                if (partie.plateau.plateau[2][0].orientation() != 1 && partie.plateau.plateau[2][1].orientation() != 3) {
                    if (vu.contains(7) == false)
                        vu.add(7);
                    if (partie.plateau.plateau[2][1].orientation() != 1 && partie.plateau.plateau[2][2].orientation() != 3) {
                        if (vu.contains(8) == false)
                            vu.add(8);
                    }
                }
            }
        } else if (i == 10) {
            if (partie.plateau.plateau[1][0].orientation() != 3) {
                if (vu.contains(3) == false)
                    vu.add(3);
                if (partie.plateau.plateau[1][0].orientation() != 1 && partie.plateau.plateau[1][1].orientation() != 3) {
                    if (vu.contains(4) == false)
                        vu.add(4);
                    if (partie.plateau.plateau[1][1].orientation() != 1 && partie.plateau.plateau[1][2].orientation() != 3) {
                        if (vu.contains(5) == false)
                            vu.add(5);
                    }
                }
            }
        } else if (i == 11) {
            if (partie.plateau.plateau[0][0].orientation() != 3) {
                if (vu.contains(0) == false)
                    vu.add(0);
                if (partie.plateau.plateau[0][0].orientation() != 1 && partie.plateau.plateau[0][1].orientation() != 3) {
                    if (vu.contains(1) == false)
                        vu.add(1);
                    if (partie.plateau.plateau[0][1].orientation() != 1 && partie.plateau.plateau[0][2].orientation() != 3) {
                        if (!vu.contains(2))
                            vu.add(2);
                    }
                }
            }
        }
    }

    public void choixJocker() {
        BoutonC.setVisible(true);
        BoutonW.setVisible(true);
        BoutonH.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Si un bouton est appuye
        if (e.getSource() == Jetons[0] && flag == 0)  { // Jeton 1
            if (partie.jeton_action_1.getcote() == 0) { // pile
                choixNbrDeplacement();
                Jetons[0].setVisible(false);
                flag = 300;
            } else if (partie.jeton_action_1.getcote() == 1) { // face
                pioche_carte();
                Jetons[0].setVisible(false);
                EtapeSupp();
            }
        } else if (e.getSource() == Jetons[1] && flag == 0) { // Jeton 2
            if (partie.jeton_action_2.getcote() == 0) { // pile
                choixNbrDeplacement();
                Jetons[1].setVisible(false);
                flag = 100;
            } else if (partie.jeton_action_2.getcote() == 1) { // face
                choixNbrDeplacement();
                Jetons[1].setVisible(false);
                flag = 200;
            }
        } else if (e.getSource() == Jetons[2] && flag == 0) { // Jeton 3
            if (partie.jeton_action_3.getcote() == 0) { // pile
                Jetons[2].setVisible(false);
                flag = 1;
            } else if (partie.jeton_action_3.getcote() == 1) { // face
                Jetons[2].setVisible(false);
                flag = 4;
            }
        } else if (e.getSource() == Jetons[3] && flag == 0) { // Jeton 4
            if (partie.jeton_action_4.getcote() == 0) { // pile
                Jetons[3].setVisible(false);
                flag = 1;
            } else if (partie.jeton_action_4.getcote() == 1) { // face
                choixJocker();
                Jetons[3].setVisible(false);
                flag = 3;
            }
        } else if (e.getSource() == Bouton1 && flag > 99) { // Si on a appuye sur un des detectives (chien, watson ou holmes) et qu'ensuite on appuie pour avancer de 1
            Bouton1.setVisible(false);
            Bouton2.setVisible(false);
            if (flag == 100) {
                partie.liste_detective.move_Chien(1);
            } else if (flag == 200) {
                partie.liste_detective.move_Watson(1);
            } else if (flag == 300) {
                partie.liste_detective.move_Holmes(1);
            }
            refreshDetective();
            flag = 0;
            EtapeSupp();
        } else if (e.getSource() == Bouton2 && flag > 99) { // Si on a appuye sur un des detectives (chien, watson ou holmes) et qu'ensuite on appuie pour avancer de 2
            Bouton1.setVisible(false);
            Bouton2.setVisible(false);
            if (flag == 100) {
                partie.liste_detective.move_Chien(2);
            } else if (flag == 200) {
                partie.liste_detective.move_Watson(2);
            } else if (flag == 300) {
                partie.liste_detective.move_Holmes(2);
            }
            refreshDetective();
            flag = 0;
            EtapeSupp();
        } else if (e.getSource() == BoutonC && flag == 3) { // Joker -> Avancer le chien
            BoutonC.setVisible(false);
            BoutonH.setVisible(false);
            BoutonW.setVisible(false);
            partie.liste_detective.move_Chien(1);
            refreshDetective();
            flag = 0;
            EtapeSupp();
        } else if (e.getSource() == BoutonW && flag == 3) { // Joker -> Avancer Watson
            BoutonC.setVisible(false);
            BoutonH.setVisible(false);
            BoutonW.setVisible(false);
            partie.liste_detective.move_Watson(1);
            refreshDetective();
            flag = 0;
            EtapeSupp();
        } else if (e.getSource() == BoutonH && flag == 3) { // Joker -> Avancer Holmes
            BoutonC.setVisible(false);
            BoutonH.setVisible(false);
            BoutonW.setVisible(false);
            partie.liste_detective.move_Holmes(1);
            refreshDetective();
            flag = 0;
            EtapeSupp();
        }
        else if (e.getSource() == BoutonTab[0][0] || e.getSource() == BoutonTab[0][1] || e.getSource() == BoutonTab[0][2]
                || e.getSource() == BoutonTab[1][0] || e.getSource() == BoutonTab[1][1] || e.getSource() == BoutonTab[1][2]
                || e.getSource() == BoutonTab[2][0] || e.getSource() == BoutonTab[2][1] || e.getSource() == BoutonTab[2][2]) {
            if (flag == 1) { // Tourner une case
                BoutonOK.setVisible(true);
                if (e.getSource() == BoutonTab[0][0] && ((flagi == 0 && flagj == 0) || flagi == -1)) {
                    partie.plateau.plateau[0][0].changer_orientation();
                    flagi = 0;
                    flagj = 0;
                } else if (e.getSource() == BoutonTab[0][1] && ((flagi == 0 && flagj == 1) || flagi == -1)) {
                    partie.plateau.plateau[0][1].changer_orientation();
                    flagi = 0;
                    flagj = 1;
                } else if (e.getSource() == BoutonTab[0][2] && ((flagi == 0 && flagj == 2) || flagi == -1)) {
                    partie.plateau.plateau[0][2].changer_orientation();
                    flagi = 0;
                    flagj = 2;
                } else if (e.getSource() == BoutonTab[1][0] && ((flagi == 1 && flagj == 0) || flagi == -1)) {
                    partie.plateau.plateau[1][0].changer_orientation();
                    flagi = 1;
                    flagj = 0;
                } else if (e.getSource() == BoutonTab[1][1] && ((flagi == 1 && flagj == 1) || flagi == -1)) {
                    partie.plateau.plateau[1][1].changer_orientation();
                    flagi = 1;
                    flagj = 1;
                } else if (e.getSource() == BoutonTab[1][2] && ((flagi == 1 && flagj == 2) || flagi == -1)) {
                    partie.plateau.plateau[1][2].changer_orientation();
                    flagi = 1;
                    flagj = 2;
                } else if (e.getSource() == BoutonTab[2][0] && ((flagi == 2 && flagj == 0) || flagi == -1)) {
                    partie.plateau.plateau[2][0].changer_orientation();
                    flagi = 2;
                    flagj = 0;
                } else if (e.getSource() == BoutonTab[2][1] && ((flagi == 2 && flagj == 1) || flagi == -1)) {
                    partie.plateau.plateau[2][1].changer_orientation();
                    flagi = 2;
                    flagj = 1;
                } else if (e.getSource() == BoutonTab[2][2] && ((flagi == 2 && flagj == 2) || flagi == -1)) {
                    partie.plateau.plateau[2][2].changer_orientation();
                    flagi = 2;
                    flagj = 2;
                }
                refreshPlateau();
            } else if (flag == 4) { // echanger une case
                if (e.getSource() == BoutonTab[0][0]) {
                    flagi = 0;
                    flagj = 0;
                } else if (e.getSource() == BoutonTab[0][1]) {
                    flagi = 0;
                    flagj = 1;
                } else if (e.getSource() == BoutonTab[0][2]) {
                    flagi = 0;
                    flagj = 2;
                } else if (e.getSource() == BoutonTab[1][0]) {
                    flagi = 1;
                    flagj = 0;
                } else if (e.getSource() == BoutonTab[1][1]) {
                    flagi = 1;
                    flagj = 1;
                } else if (e.getSource() == BoutonTab[1][2]) {
                    flagi = 1;
                    flagj = 2;
                } else if (e.getSource() == BoutonTab[2][0]) {
                    flagi = 2;
                    flagj = 0;
                } else if (e.getSource() == BoutonTab[2][1]) {
                    flagi = 2;
                    flagj = 1;
                } else if (e.getSource() == BoutonTab[2][2]) {
                    flagi = 2;
                    flagj = 2;
                }
                flag = 20;
            } else if (flag == 20) { // echange une case partie 2
                if (e.getSource() == BoutonTab[0][0] && (flagi != 0 || flagj != 0)) {
                    District flagDistrict = partie.plateau.plateau[flagi][flagj];
                    partie.plateau.plateau[flagi][flagj] = partie.plateau.plateau[0][0];
                    partie.plateau.plateau[0][0] = flagDistrict;
                    refreshPlateau();
                    flag = 0;
                    flagi = -1;
                    flagj = -1;
                    EtapeSupp();
                } else if (e.getSource() == BoutonTab[0][1] && (flagi != 0 || flagj != 1)) {
                    District flagDistrict = partie.plateau.plateau[flagi][flagj];
                    partie.plateau.plateau[flagi][flagj] = partie.plateau.plateau[0][1];
                    partie.plateau.plateau[0][1] = flagDistrict;
                    refreshPlateau();
                    flag = 0;
                    flagi = -1;
                    flagj = -1;
                    EtapeSupp();
                } else if (e.getSource() == BoutonTab[0][2] && (flagi != 0 || flagj != 2)) {
                    District flagDistrict = partie.plateau.plateau[flagi][flagj];
                    partie.plateau.plateau[flagi][flagj] = partie.plateau.plateau[0][2];
                    partie.plateau.plateau[0][2] = flagDistrict;
                    EtapeSupp();
                    flag = 0;
                    flagi = -1;
                    flagj = -1;
                    EtapeSupp();
                } else if (e.getSource() == BoutonTab[1][0] && (flagi != 1 || flagj != 0)) {
                    District flagDistrict = partie.plateau.plateau[flagi][flagj];
                    partie.plateau.plateau[flagi][flagj] = partie.plateau.plateau[1][0];
                    partie.plateau.plateau[1][0] = flagDistrict;
                    refreshPlateau();
                    flag = 0;
                    flagi = -1;
                    flagj = -1;
                    EtapeSupp();
                } else if (e.getSource() == BoutonTab[1][1] && (flagi != 1 || flagj != 1)) {
                    District flagDistrict = partie.plateau.plateau[flagi][flagj];
                    partie.plateau.plateau[flagi][flagj] = partie.plateau.plateau[1][1];
                    partie.plateau.plateau[1][1] = flagDistrict;
                    refreshPlateau();
                    flag = 0;
                    flagi = -1;
                    flagj = -1;
                    EtapeSupp();
                } else if (e.getSource() == BoutonTab[1][2] && (flagi != 1 || flagj != 2)) {
                    District flagDistrict = partie.plateau.plateau[flagi][flagj];
                    partie.plateau.plateau[flagi][flagj] = partie.plateau.plateau[1][2];
                    partie.plateau.plateau[1][2] = flagDistrict;
                    refreshPlateau();
                    flag = 0;
                    flagi = -1;
                    flagj = -1;
                    EtapeSupp();
                } else if (e.getSource() == BoutonTab[2][0] && (flagi != 2 || flagj != 0)) {
                    District flagDistrict = partie.plateau.plateau[flagi][flagj];
                    partie.plateau.plateau[flagi][flagj] = partie.plateau.plateau[2][0];
                    partie.plateau.plateau[2][0] = flagDistrict;
                    refreshPlateau();
                    flag = 0;
                    flagi = -1;
                    flagj = -1;
                    EtapeSupp();
                } else if (e.getSource() == BoutonTab[2][1] && (flagi != 2 || flagj != 1)) {
                    District flagDistrict = partie.plateau.plateau[flagi][flagj];
                    partie.plateau.plateau[flagi][flagj] = partie.plateau.plateau[2][1];
                    partie.plateau.plateau[2][1] = flagDistrict;
                    refreshPlateau();
                    flag = 0;
                    flagi = -1;
                    flagj = -1;
                    EtapeSupp();
                } else if (e.getSource() == BoutonTab[2][2] && (flagi != 2 || flagj != 2)) {
                    District flagDistrict = partie.plateau.plateau[flagi][flagj];
                    partie.plateau.plateau[flagi][flagj] = partie.plateau.plateau[2][2];
                    partie.plateau.plateau[2][2] = flagDistrict;
                    refreshPlateau();
                    flag = 0;
                    flagi = -1;
                    flagj = -1;
                    EtapeSupp();
                }
            }
        } else if (e.getSource() == BoutonOK) { // Quand on a finit de tourner
            flagi = -1;
            flagj = -1;
            flag = 0;
            BoutonOK.setVisible(false);
            EtapeSupp();
        } else if (e.getSource() == CarteMechant) { // Tourner la carte mechant pour la voir
            if (partie.joueur_mrjack.visible) {
                CarteMechant.setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/Carte" + partie.joueur_mrjack.mrJack.nom_carte + ".png")));
            } else {
                CarteMechant.setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/CarteRien.png")));
            }
            partie.joueur_mrjack.visible = !partie.joueur_mrjack.visible ;
        } else if (e.getSource() == CartesMechants[0] || e.getSource() == CartesMechants[1]
                || e.getSource() == CartesMechants[2] || e.getSource() == CartesMechants[3]) { // Pareil mais avec les autres
            if (e.getSource() == CartesMechants[0]) {
                if (partie.joueur_mrjack.visibleAutre[0]) {
                    CartesMechants[0].setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/Carte" + partie.joueur_mrjack.carte[0].nom_carte + ".png")));
                } else if (!partie.joueur_mrjack.visibleAutre[0]) {
                    CartesMechants[0].setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/CarteRien.png")));
                }
                partie.joueur_mrjack.visibleAutre[0] = !partie.joueur_mrjack.visibleAutre[0] ;
            } else if (e.getSource() == CartesMechants[1]) {
                if (partie.joueur_mrjack.visibleAutre[1]) {
                    CartesMechants[1].setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/Carte" + partie.joueur_mrjack.carte[1].nom_carte + ".png")));
                } else if (!partie.joueur_mrjack.visibleAutre[1]) {
                    CartesMechants[1].setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/CarteRien.png")));
                }
                partie.joueur_mrjack.visibleAutre[1] = !partie.joueur_mrjack.visibleAutre[1] ;
            } else if (e.getSource() == CartesMechants[2]) {
                if (partie.joueur_mrjack.visibleAutre[2]) {
                    CartesMechants[2].setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/Carte" + partie.joueur_mrjack.carte[2].nom_carte + ".png")));
                } else if (!partie.joueur_mrjack.visibleAutre[2]) {
                    CartesMechants[2].setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/CarteRien.png")));
                }
                partie.joueur_mrjack.visibleAutre[2] = !partie.joueur_mrjack.visibleAutre[2] ;
            } else if (e.getSource() == CartesMechants[3]) {
                if (partie.joueur_mrjack.visibleAutre[3]) {
                    CartesMechants[3].setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/Carte" + partie.joueur_mrjack.carte[3].nom_carte + ".png")));
                } else if (!partie.joueur_mrjack.visibleAutre[3]) {
                    CartesMechants[3].setIcon(new ImageIcon(Fenetre.class.getResource("/CasePerso/CarteRien.png")));
                }
                partie.joueur_mrjack.visibleAutre[3] = !partie.joueur_mrjack.visibleAutre[3] ;
            }
        }
    }
}
