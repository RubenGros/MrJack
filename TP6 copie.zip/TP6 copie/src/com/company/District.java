package com.company;
import java.util.*;


public class District {

    public Boolean suspect_vide= true;
    public final String nom;
    public Boolean[] Face_suspect= {false,true,true,true};
    public Boolean[] Face_vide;
    public final int ID;


    public District(String nom, Boolean[] Face_vide, int ID) {
        this.nom = nom;
        this.Face_vide = Face_vide;
        this.ID = ID;
        initialisation_District();
    }

    public void initialisation_District() {
        Random r = new Random();
        int n = r.nextInt(4);
        for (int i = 0; i<n;i++) {
            changer_orientation();
        }
    }

    public void tourner() {
        this.suspect_vide=false;
    }

    public void changer_orientation() {
        Boolean[] v1 = {true,true,true,true};
        Boolean[] v2 = {true,true,true,true};
        for (int j=0; j<4;j++){
            v1[(j+1)%4]=this.Face_suspect[j];
            v2[(j+1)%4]=this.Face_vide[j];
        }
        this.Face_suspect=v1;
        this.Face_vide=v2;

    }

    public int orientation(){
        int a =0;
        for (int i =0; i<4;i++){
            if (!Face_suspect[i]){
                a = i;
            }
        }
        return a;
    }
}