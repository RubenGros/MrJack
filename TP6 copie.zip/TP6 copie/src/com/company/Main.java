package com.company;

public class Main {
    public static void main(String[] args) {
        Fenetre mywindow= new Fenetre();
        mywindow.setVisible(true);
    }
}