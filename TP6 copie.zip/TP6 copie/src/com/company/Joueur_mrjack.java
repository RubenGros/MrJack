package com.company;


public class Joueur_mrjack {

    public int score_sablier=0;
    public int score_sablier_visible=0;
    public Alibi mrJack;
    public Alibi[] carte = new Alibi[4];
    public Boolean visible= true;
    public Boolean[] visibleAutre={false,false,false,false};

    public Joueur_mrjack(Alibi personne) {
        this.carte[0] = new Alibi("X", -1,11);
        this.carte[1] = new Alibi("X", -1,11);
        this.carte[2] = new Alibi("X", -1,11);
        this.carte[3] = new Alibi("X", -1,11);
        mrJack= personne;
    }
}