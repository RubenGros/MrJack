package com.company;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DeckAlibi {
    private ArrayDeque<Alibi> deck = new ArrayDeque<>();

    DeckAlibi (){
        InitialisationDeckAlibi();
    }


    public Alibi popPersonne(){
        Alibi personne = this.deck.pop();
        return personne;
    }


    private void InitialisationDeckAlibi(){
        List<Alibi> liste = new ArrayList<>();
        liste.add(new Alibi("Bleu",0,1));
        liste.add(new Alibi("Vert",1, 2));
        liste.add(new Alibi("Orange",1, 3));
        liste.add(new Alibi("Blanc",1, 4));
        liste.add(new Alibi("Jaune",1, 5));
        liste.add(new Alibi("Gris",1, 6));
        liste.add(new Alibi("Rose",2, 7));
        liste.add(new Alibi("Noir",0, 8));
        liste.add(new Alibi("Violet",1, 9));

        while (liste.size()>0) {
            Random nombre = new Random();
            int n = nombre.nextInt(liste.size());
            deck.addLast(liste.get(n));
            liste.remove(n);
        }
        this.deck.removeFirst();
    }
}
