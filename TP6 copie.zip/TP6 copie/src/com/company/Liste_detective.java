package com.company;


public class Liste_detective {

    public int[][] Liste=new int[12][3];

    public Liste_detective() {
        for (int i =0;i<12;i++){
            for (int j=0;j<3;j++) {
                 this.Liste[i][j] = 0;
            }
        }
        this.Liste[11][0]=1;
        this.Liste[3][1]=1;
        this.Liste[7][2]=1;
    }

    public void move_Holmes(int nbr) {
        int a=0;
        for (int i=0;i<12;i++){
            if (Liste[i][0]==1){
                a=i;
            }
        }
        Liste[a][0]=0;
        Liste[(a+nbr)%12][0]=1;
    }

    public void move_Watson(int nbr) { // 1 pour ajouter de 1 et 2 pour ajouter de deux
        int a=0;
        for (int i=0;i<12;i++){
            if (Liste[i][1]==1){
                a=i;
            }
        }
        Liste[a][1]=0;
        Liste[(a+nbr)%12][1]=1;
    }

    public void move_Chien(int nbr) {
        int a=0;
        for (int i=0;i<12;i++){
            if (Liste[i][2]==1){
                a=i;
            }
        }
        Liste[a][2]=0;
        Liste[(a+nbr)%12][2]=1;
    }

    public int[] getPosition(){
        int[] a = {0,0,0};

        for (int i=0; i<12; i++){
            for (int j=0;j<3;j++) {
                if (Liste[i][j] == 1) {
                    a[j] = i;
                }
            }
        }
        return a;
    }

    public Boolean verifPosition(int numero_position){
        Boolean bool = false;
        for (int i=0;i<3;i++){
            if(Liste[numero_position][i]==1){
                bool = true;
            }
        }
        return bool;
    }

    public String[] getNom(){
        String[] name = new String[3];
        name[0] = "Watson";
        name[1] = "Chien";
        name[2] = "Holmes";
        return name;
    }
}