package com.company;
import java.util.*;


public class Partie {

    public Plateau plateau = new Plateau();
    public Action_1 jeton_action_1 = new Action_1();
    public Action_2 jeton_action_2 = new Action_2();
    public Action_3 jeton_action_3 = new Action_3();
    public Action_4 jeton_action_4 = new Action_4();
    public Liste_detective liste_detective = new Liste_detective();
    public int numero_tour=1;
    public int numero_Etape=0;
    public Joueur_mrjack joueur_mrjack;
    public DeckAlibi deck = new DeckAlibi();

    public Partie() {
        joueur_mrjack = new Joueur_mrjack(deck.popPersonne());
    }
}