package com.company;
import java.util.*;


public class Plateau {

    public District[][] plateau = new District[3][3];

    public Plateau() {
        initialisation_plateau();
    }

    public void initialisation_plateau() {
        Boolean[] a = {false,true,true,true};
        Boolean[] b = {true,true,true,true};
        List<District> liste = new ArrayList<>();
        liste.add(new District("Bleu",a,1));
        liste.add(new District("Vert",a,2));
        liste.add(new District("Orange",a,3));
        liste.add(new District("Blanc",a,4));
        liste.add(new District("Jaune",a,5));
        liste.add(new District("Gris",b,6));
        liste.add(new District("Rose",a,7));
        liste.add(new District("Noir",a,8));
        liste.add(new District("Violet",a,9));

        for (int i=0; i<3;i++){
            for (int j=0; j<3;j++){
                Random nombre = new Random();
                int n = nombre.nextInt(liste.size());
                plateau[i][j] = liste.get(n);
                liste.remove(n);
            }
        }
    }

}