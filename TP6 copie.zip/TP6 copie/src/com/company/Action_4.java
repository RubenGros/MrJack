package com.company;

import java.util.Random;
import java.util.Scanner;

public class Action_4 {

    public Boolean Recto_verso=true;


    public Action_4() {
    }


    public void retourner_jeton() {
        Recto_verso= !Recto_verso;
    }

    public int getcote(){
        int a= 0;
        if (Recto_verso){
            a=1;
        }
        return a;
    }
    public void rand_cote(){
        Random rand = new Random();
        Recto_verso = rand.nextBoolean();
    }

}