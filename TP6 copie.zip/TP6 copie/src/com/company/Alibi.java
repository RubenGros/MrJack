package com.company;

public class Alibi {
    public String nom_carte;
    public int nombre_sablier;
    public final int ID;

    Alibi (String nom_carte, int nombre_sablier, int ID){
        this.nom_carte = nom_carte;
        this.nombre_sablier = nombre_sablier;
        this.ID = ID;
    }
}
